file(REMOVE_RECURSE
  "CMakeFiles/Lab6_tests.dir/tests/game_tests.cpp.o"
  "CMakeFiles/Lab6_tests.dir/tests/game_tests.cpp.o.d"
  "Lab6_tests"
  "Lab6_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Lab6_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
