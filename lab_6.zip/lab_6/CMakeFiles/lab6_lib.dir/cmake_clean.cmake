file(REMOVE_RECURSE
  "CMakeFiles/lab6_lib.dir/src/factory/NPCFactory.cpp.o"
  "CMakeFiles/lab6_lib.dir/src/factory/NPCFactory.cpp.o.d"
  "CMakeFiles/lab6_lib.dir/src/mobs/NPC.cpp.o"
  "CMakeFiles/lab6_lib.dir/src/mobs/NPC.cpp.o.d"
  "CMakeFiles/lab6_lib.dir/src/mobs/Orc.cpp.o"
  "CMakeFiles/lab6_lib.dir/src/mobs/Orc.cpp.o.d"
  "CMakeFiles/lab6_lib.dir/src/mobs/Outlaw.cpp.o"
  "CMakeFiles/lab6_lib.dir/src/mobs/Outlaw.cpp.o.d"
  "CMakeFiles/lab6_lib.dir/src/mobs/Werewolf.cpp.o"
  "CMakeFiles/lab6_lib.dir/src/mobs/Werewolf.cpp.o.d"
  "CMakeFiles/lab6_lib.dir/src/observers/ConsoleObserver.cpp.o"
  "CMakeFiles/lab6_lib.dir/src/observers/ConsoleObserver.cpp.o.d"
  "CMakeFiles/lab6_lib.dir/src/observers/LogObserver.cpp.o"
  "CMakeFiles/lab6_lib.dir/src/observers/LogObserver.cpp.o.d"
  "liblab6_lib.a"
  "liblab6_lib.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/lab6_lib.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
