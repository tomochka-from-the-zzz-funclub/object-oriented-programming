
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/tamara/2_cours/OOP/lab_6/src/factory/NPCFactory.cpp" "CMakeFiles/lab6_lib.dir/src/factory/NPCFactory.cpp.o" "gcc" "CMakeFiles/lab6_lib.dir/src/factory/NPCFactory.cpp.o.d"
  "/home/tamara/2_cours/OOP/lab_6/src/mobs/NPC.cpp" "CMakeFiles/lab6_lib.dir/src/mobs/NPC.cpp.o" "gcc" "CMakeFiles/lab6_lib.dir/src/mobs/NPC.cpp.o.d"
  "/home/tamara/2_cours/OOP/lab_6/src/mobs/Orc.cpp" "CMakeFiles/lab6_lib.dir/src/mobs/Orc.cpp.o" "gcc" "CMakeFiles/lab6_lib.dir/src/mobs/Orc.cpp.o.d"
  "/home/tamara/2_cours/OOP/lab_6/src/mobs/Outlaw.cpp" "CMakeFiles/lab6_lib.dir/src/mobs/Outlaw.cpp.o" "gcc" "CMakeFiles/lab6_lib.dir/src/mobs/Outlaw.cpp.o.d"
  "/home/tamara/2_cours/OOP/lab_6/src/mobs/Werewolf.cpp" "CMakeFiles/lab6_lib.dir/src/mobs/Werewolf.cpp.o" "gcc" "CMakeFiles/lab6_lib.dir/src/mobs/Werewolf.cpp.o.d"
  "/home/tamara/2_cours/OOP/lab_6/src/observers/ConsoleObserver.cpp" "CMakeFiles/lab6_lib.dir/src/observers/ConsoleObserver.cpp.o" "gcc" "CMakeFiles/lab6_lib.dir/src/observers/ConsoleObserver.cpp.o.d"
  "/home/tamara/2_cours/OOP/lab_6/src/observers/LogObserver.cpp" "CMakeFiles/lab6_lib.dir/src/observers/LogObserver.cpp.o" "gcc" "CMakeFiles/lab6_lib.dir/src/observers/LogObserver.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
