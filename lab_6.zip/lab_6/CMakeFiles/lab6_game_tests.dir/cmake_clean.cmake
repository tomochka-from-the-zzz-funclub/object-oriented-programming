file(REMOVE_RECURSE
  "CMakeFiles/lab6_game_tests.dir/tests/game_tests.cpp.o"
  "CMakeFiles/lab6_game_tests.dir/tests/game_tests.cpp.o.d"
  "lab6_game_tests"
  "lab6_game_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/lab6_game_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
